# UnityML
This repo contains the source code for the python package - UnityML.

- Command Prompt:
```
pip install unityml && unityml
```
- Powershell:
```
pip install unityml ; unityml
```